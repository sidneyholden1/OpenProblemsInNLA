"""Read-only observed public heads and PR duplicate audit for IV-06.
Preserves API responses. Never changes a branch or sends a GitHub message.
"""
from pathlib import Path
import concurrent.futures,datetime,hashlib,json,subprocess
P=Path(__file__).resolve().parent
GH='/tmp/nla-submission-tools/gh_2.100.0_macOS_arm64/bin/gh'
repo='ajt60gaibb/OpenProblemsInNLA'
forks=[x['full_name'] for page in json.loads((P/'forks-pages.json').read_text()) for x in page]
names=[repo]+forks
jobs=[(r,kind) for r in names for kind in ['branches','pulls'] if not(r==repo and kind=='pulls')]
def fetch(job):
 r,kind=job;ep='repos/'+r+'/'+kind+'?per_page=100'+('&state=all' if kind=='pulls' else '')
 proc=subprocess.run([GH,'api','--paginate','--slurp',ep],capture_output=True)
 key=r.replace('/','_')+'-'+kind
 (P/(key+'.json')).write_bytes(proc.stdout);(P/(key+'.stderr')).write_bytes(proc.stderr)
 if proc.returncode:raise RuntimeError((r,kind,proc.stderr.decode()))
 return r,kind,[x for page in json.loads(proc.stdout) for x in page]
results=list(concurrent.futures.ThreadPoolExecutor(max_workers=4).map(fetch,jobs))
branches={r:v for r,k,v in results if k=='branches'}
prs={r:v for r,k,v in results if k=='pulls'}
prs[repo]=[x for page in json.loads((P/'upstream-pr-pages.json').read_text()) for x in page]
heads=[];matches=[]
for r,bs in branches.items():
 for b in bs:heads.append({'repository':r,'branch':b['name'],'sha':b['commit']['sha']})
for r,ps in prs.items():
 for x in ps:
  text=' '.join([x['title'],x.get('body')or'',x['head']['ref']]).lower()
  if 'iv-06' in text or 'iv06' in text:
   matches.append({'repository':r,'number':x['number'],'title':x['title'],'state':x['state'],'merged_at':x.get('merged_at'),'head':x['head']['label'],'url':x['html_url']})
report={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repositories':names,'branch_counts':{r:len(bs) for r,bs in branches.items()},'pr_counts':{r:len(ps) for r,ps in prs.items()},'heads':heads,'matching_PRs':matches,'scope':'All public forks listed by upstream and all current heads/PRs returned by the API; deleted/private heads and unpublished work are outside observable scope. Head files are checked separately.'}
(P/'network-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['branch_counts','pr_counts','matching_PRs']},indent=2))
print('HEADS',len(heads),'UNIQUE',len({h['sha'] for h in heads}))
