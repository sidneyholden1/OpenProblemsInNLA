# NR-03 — Exact four-bit theorem and certificates

**Result proved here:** `rank_+(C_4) = 16`, for the fixed real nonnegative matrix
`C_n(a,b) = (1 - popcount(a & b))^2`.

**Overall scope: PARTIAL.** This is not a proof of `rank_+(C_n) = 2^n` for every
`n >= 3`. The repository already reports the three-bit theorem. This package
adds a complete, exact computer-assisted argument for four bits; it does not
settle the remaining assertion for every `n >= 5`.

The result has been checked in this session, including reproduction using two
C++ compilers. It has not received external peer review and is not a
proof-assistant formalization. No repository content was changed.

## Read the argument

Start with **report.pdf**. Its editable LaTeX source is **report.tex**.
The main theorem depends on an exhaustive finite support classification and the
exact rejection certificates in this archive. It is valid over the real
numbers: the verification does not restrict hypothetical factors to rational
coordinates.

The fixed values at intersections of size greater than one matter. Results
about choosing those entries freely are not substitutions for this problem.

## Verify everything

Requirements: Python 3.10 or later and `g++` or `clang++` supporting C++17.
There are **no required Python packages** and no network calls.

From the extracted directory:

```sh
python3 verify_all.py
python3 code/self_tests.py
```

Select another compiler or retain the build and recomputed cover bases:

```sh
python3 verify_all.py --compiler clang++ --work-dir verification_build
```

The main verifier:

1. Regenerates all 130 maximal positive rectangles and the exact entry/face
   incidence model; validates every integer pruning dual.
2. Repeats the exhaustive cover searches, including the budget-fifteen search.
3. Reconstructs the complete family of possible support multisets, including
   repeated atom types, and its 521 symmetry representatives.
4. Rebuilds every necessary integer linear system and checks all exact
   contradictions.

The successful ending is:

```text
RESULT: rank_+(C_4) = 16. No factorization with fifteen or fewer terms exists.
SCOPE: this proves the four-bit case, not the conjecture for every n >= 5.
```

The recorded complete runs took about 20 seconds with GCC and 13 seconds with
Clang in this environment. Runtime varies by machine. Both logs are included.
A failed assertion, exception, nonzero subprocess exit, missing case, malformed
certificate, or incomplete search prevents a successful result.

## What the exact proof checks

Every atom has a positive rectangle support, enlarged only for labeling to one
of 130 maximal rectangles. Zeros inside an assigned rectangle remain allowed.
Each positive entry must be covered. Each two-coordinate face is a copy of
`C_2`, of ordinary rank four, so at least four assigned atoms must meet it.

Binary cover search produces a **cover basis**: every feasible set within the
budget contains a returned leaf. It does not pretend to list every feasible
superset. The separate multiset construction accounts for this distinction and
for repeated atoms.

A hypothetical factorization with at most fifteen atoms can be padded by
splitting an atom to exactly fifteen. Its support multiset falls within a
complete overapproximation of 16,309 multisets, reducing to 521 representatives
under coordinate permutations and transposition. The exact rejections are:

| Method | Cases |
|---|---:|
| Inconsistent unique-entry product cycle | 106 |
| Integer Farkas certificate for forced-ratio equations | 413 |
| Nonsingular 4-by-4 submatrix with only three active atoms | 1 |
| Further exact rank-one propagation, then an integer Farkas certificate | 1 |
| **Total** | **521** |

The last case also has a hand proof: diagonal entries force normalized triple
columns to have values three on their own triple and one on the other triples.
The full-set row then forces four factor coordinates to be `2/3`, causing two
atoms to contribute `4/3` at an entry whose prescribed value is one.

All Farkas vectors are integer data. The verifier tests `A^T y >= 0` and
`b^T y < 0` exactly. The numerical optimizer used in discovery is not trusted or
needed for these checks.

## Additional scope check

`data/n5_relaxation_witness.json` gives 31 maximal rectangles for five bits that
cover all positive entries and meet the full conjectured active counts on all
proper coordinate faces. This refutes a support/face-count-only induction
shortcut. It is **not an NMF or a counterexample to NR-03**: the same support
pattern fails an exact unique-entry cycle test. The self-tests verify both
statements.

## Archive contents

- `report.pdf`, `report.tex`: proof and editable source.
- `verify_all.py`: complete solver-free proof reproduction.
- `code/`: exact core, exhaustive C++ search, and independent self-tests.
- `data/`: exact models, cover bases, all 521 representatives, every rejection
  certificate, and the five-bit relaxation-only example.
- `logs/`: GCC and Clang reproduction, self-tests, and environment information.
- `discovery/`: optional LP-based regeneration of Farkas vectors.
- `SOURCES.md`: source scope and references.
- `STATUS.md`: exact boundary of the result.
- `SHA256SUMS.txt`: integrity hashes for the delivered files.

The archive contains no compiler binaries, fonts, or external paper copies.
