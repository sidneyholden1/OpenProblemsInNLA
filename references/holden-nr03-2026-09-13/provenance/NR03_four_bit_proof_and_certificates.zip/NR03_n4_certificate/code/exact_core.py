"""Exact mathematical models for the NR-03 four-bit certificate.

Only the Python standard library is used. Integers are arbitrary precision;
ratios forced by unique entries are represented by fractions.Fraction.
No numerical tolerance is used in a verification decision.
"""
from collections import defaultdict
from fractions import Fraction
from math import isqrt
from itertools import combinations, combinations_with_replacement, permutations, product


def require(condition, message):
    if not condition:
        raise ValueError(message)


def matrix(n):
    return [[(1 - (a & b).bit_count()) ** 2 for b in range(1 << n)]
            for a in range(1 << n)]


def members(mask, size):
    return [a for a in range(size) if (mask >> a) & 1]


def maximal_rectangles(n):
    """All maximal positive rectangles, sorted by (row-mask, column-mask)."""
    size = 1 << n
    neighbors = [sum(1 << b for b in range(size)
                     if (a & b).bit_count() != 1) for a in range(size)]
    column_sets = {(1 << size) - 1}
    for neighbor in neighbors:
        column_sets |= {s & neighbor for s in column_sets}
    rectangles = []
    for s in column_sets:
        if s:
            r = sum(1 << a for a in range(size) if neighbors[a] & s == s)
            if r:
                rectangles.append((r, s))
    return sorted(rectangles)


def model_incidence(n=4):
    """Entry coverage and distinct rank-four two-coordinate face constraints."""
    size = 1 << n
    rectangles = maximal_rectangles(n)
    arcs = [(a, b) for a in range(size) for b in range(size)
            if (a & b).bit_count() != 1]
    coverage = [[int(bool(r >> a & 1) and bool(s >> b & 1))
                 for r, s in rectangles] for a, b in arcs]
    faces = set()
    for free in combinations(range(n), 2):
        fixed = [j for j in range(n) if j not in free]
        for states in product([(0, 0), (0, 1), (1, 0)], repeat=n - 2):
            rows = sum(1 << a for a in range(size)
                       if all(((a >> j) & 1) == u
                              for j, (u, v) in zip(fixed, states)))
            cols = sum(1 << b for b in range(size)
                       if all(((b >> j) & 1) == v
                              for j, (u, v) in zip(fixed, states)))
            faces.add(tuple(int(bool(r & rows) and bool(s & cols))
                            for r, s in rectangles))
    return rectangles, arcs, coverage, sorted(faces)


def read_model(path):
    tokens = list(map(int, path.read_text().split()))
    position = 0

    def take(count):
        nonlocal position
        require(position + count <= len(tokens), 'Truncated model')
        result = tokens[position:position + count]
        position += count
        return result

    nv, ne, nf, nd = take(4)
    coverage = [take(nv) for _ in range(ne)]
    faces = [take(nv + 1) for _ in range(nf)]
    duals = [take(ne + 1) for _ in range(nd)]
    require(position == len(tokens), 'Trailing model data')
    return nv, coverage, faces, duals


def verify_model(path, use_faces):
    rectangles, arcs, coverage, face_incidence = model_incidence()
    nv, stored_coverage, stored_faces, duals = read_model(path)
    require(nv == len(rectangles) == 130, 'Wrong rectangle count')
    require(len(arcs) == 148 and stored_coverage == coverage,
            'Model entry constraints do not match C_4')
    expected_faces = [[4] + list(f) for f in face_incidence] if use_faces else []
    require(stored_faces == expected_faces, 'Incorrect face constraints')
    require(len(face_incidence) == 49, 'Unexpected distinct face count')
    for dual in duals:
        denominator, *weights = dual
        require(denominator > 0 and all(w >= 0 for w in weights),
                'Invalid dual signs')
        for j in range(nv):
            require(sum(w * row[j] for w, row in zip(weights, coverage))
                    <= denominator, 'Invalid exact pruning dual')
    return rectangles, coverage, face_incidence


def symmetry_group(rectangles, n=4):
    size = 1 << n
    index = {rectangle: i for i, rectangle in enumerate(rectangles)}
    group = []
    for permutation in permutations(range(n)):
        mapping = [sum(((a >> j) & 1) << permutation[j] for j in range(n))
                   for a in range(size)]

        def permute_mask(mask):
            return sum(1 << mapping[a] for a in members(mask, size))

        for transpose in (False, True):
            group.append([index[(permute_mask(s), permute_mask(r))
                                if transpose else (permute_mask(r), permute_mask(s))]
                          for r, s in rectangles])
    require(len({tuple(g) for g in group}) == 48, 'Bad symmetry group')
    return group


def read_cover_basis(path, capacity, coverage, faces):
    basis = [tuple(map(int, line.split()))
             for line in path.read_text().splitlines() if line.strip()]
    for cover in basis:
        require(len(set(cover)) == len(cover) <= capacity, 'Invalid cover cardinality')
        require(all(0 <= j < 130 for j in cover), 'Rectangle index out of range')
        require(all(any(row[j] for j in cover) for row in coverage),
                'Returned leaf misses a positive entry')
        require(all(sum(row[j] for j in cover) >= 4 for row in faces),
                'Returned leaf violates a face constraint')
    return basis


def classify_multisets(faces_basis15, support_basis14, face_incidence, group):
    """A complete overapproximation of possible fifteen-atom support multisets.

    The enumeration's leaves are a COVER BASIS, not necessarily all feasible
    subsets. Every feasible subset of the requested budget contains a leaf.
    This routine accounts explicitly for supersets and repeated atom types.
    """
    candidates = set()
    for base in faces_basis15:
        if len(base) == 15:
            candidates.add(tuple(sorted(base)))
        else:
            require(len(base) == 14, 'Unexpected small face-cover basis leaf')
            for a in range(130):
                candidates.add(tuple(sorted(base + (a,))))
    for base in support_basis14:
        counts = [sum(row[j] for j in base) for row in face_incidence]
        if len(base) == 14:
            extensions = [(a,) for a in base]
        else:
            require(len(base) == 13, 'Unexpected small support-cover basis leaf')
            extensions = combinations_with_replacement(range(130), 2)
        for extension in extensions:
            if all(count + sum(row[j] for j in extension) >= 4
                   for count, row in zip(counts, face_incidence)):
                candidates.add(tuple(sorted(base + tuple(extension))))
    representatives = sorted({min(tuple(sorted(g[j] for j in candidate)) for g in group)
                              for candidate in candidates})
    return len(candidates), representatives


def build_exact_equations(C, rectangles, ids):
    """Necessary sparse integer equations A*x=b, x>=0 for an atom support list.

    A variable is the contribution of atom k at a cell (a,b) in its assigned
    maximal rectangle; it is NOT an unconstrained original factor entry.
    Unique cells give strictly positive products, hence exact within-component
    factor ratios. Positivity of any other entry is never assumed.
    """
    size = len(C)
    count = [[0] * size for _ in range(size)]
    cells, maps = [], []
    for k, rectangle_id in enumerate(ids):
        rows, cols = rectangles[rectangle_id]
        mapping = {}
        for a in members(rows, size):
            for b in members(cols, size):
                mapping[a, b] = len(cells)
                cells.append((k, a, b))
                count[a][b] += 1
        maps.append(mapping)
    equations, rhs = [], []
    for a in range(size):
        for b in range(size):
            if C[a][b] > 0:
                equations.append({mapping[a, b]: 1 for mapping in maps if (a, b) in mapping})
                rhs.append(C[a][b])
    inconsistent = False
    for mapping in maps:
        rows = sorted({a for a, b in mapping})
        cols = sorted({b for a, b in mapping})
        adjacency = defaultdict(list)
        for a, b in mapping:
            if count[a][b] == 1:
                adjacency[a].append((size + b, C[a][b]))
                adjacency[size + b].append((a, C[a][b]))
        values, components = {}, []
        for root in sorted(adjacency):
            if root in values:
                continue
            values[root] = Fraction(1)
            queue = [root]
            for u in queue:
                for v, product_value in adjacency[u]:
                    value = Fraction(product_value) / values[u]
                    if v in values:
                        if values[v] != value:
                            inconsistent = True
                    else:
                        values[v] = value
                        queue.append(v)
            components.append(queue)
        for component in components:
            component_rows = [u for u in component if u < size]
            component_cols = [u - size for u in component if u >= size]
            if component_rows:
                a0 = component_rows[0]
                for a in component_rows[1:]:
                    ratio = values[a] / values[a0]
                    for b in cols:
                        equations.append({mapping[a, b]: ratio.denominator,
                                          mapping[a0, b]: -ratio.numerator})
                        rhs.append(0)
            if component_cols:
                b0 = component_cols[0]
                for b in component_cols[1:]:
                    ratio = values[size + b] / values[size + b0]
                    for a in rows:
                        equations.append({mapping[a, b]: ratio.denominator,
                                          mapping[a, b0]: -ratio.numerator})
                        rhs.append(0)
            for a in component_rows:
                for b in component_cols:
                    value = values[a] * values[size + b]
                    equations.append({mapping[a, b]: value.denominator})
                    rhs.append(value.numerator)
    return equations, rhs, inconsistent, cells


def check_linear_combination(equations, rhs, combination, target, value):
    coefficients = defaultdict(int)
    constant = 0
    for index, weight in combination:
        require(isinstance(index, int) and 0 <= index < len(equations), 'Invalid equation index')
        require(isinstance(weight, int), 'Noninteger derivation weight')
        for variable, coefficient in equations[index].items():
            coefficients[variable] += weight * coefficient
        constant += weight * rhs[index]
    coefficients = {j: v for j, v in coefficients.items() if v}
    require(coefficients == target and constant == value, 'Invalid exact affine consequence')


def add_propagations(equations, rhs, cells, propagations):
    cell_index = {cell: j for j, cell in enumerate(cells)}
    for proof in propagations:
        k, row = proof['atom'], proof['row']
        b1, b2 = proof['column1'], proof['column2']
        c1, c2 = proof['first_value'], proof['second_value']
        require(isinstance(c1, int) and isinstance(c2, int) and c1 > 0 and c2 > 0,
                'Propagation requires two strictly positive known contributions')
        require(b1 != b2, 'Repeated propagation column')
        j1, j2 = cell_index[k, row, b1], cell_index[k, row, b2]
        check_linear_combination(equations, rhs, proof['first_derivation'], {j1: 1}, c1)
        check_linear_combination(equations, rhs, proof['second_derivation'], {j2: 1}, c2)
        rows = sorted({a for atom, a, b in cells if atom == k})
        for a in rows:
            equations.append({cell_index[k, a, b1]: c2, cell_index[k, a, b2]: -c1})
            rhs.append(0)


def check_farkas(equations, rhs, variable_count, certificate):
    require(certificate['equations'] == len(equations), 'Wrong Farkas row count')
    require(certificate['variables'] == variable_count, 'Wrong Farkas variable count')
    vector = [0] * variable_count
    constant, seen = 0, set()
    for index, weight in certificate['y']:
        require(isinstance(index, int) and 0 <= index < len(equations), 'Bad Farkas index')
        require(index not in seen and isinstance(weight, int), 'Bad or repeated Farkas term')
        seen.add(index)
        for j, coefficient in equations[index].items():
            vector[j] += weight * coefficient
        constant += weight * rhs[index]
    require(all(v >= 0 for v in vector), 'A^T y is not nonnegative')
    require(constant == certificate['b_dot_y'] and constant < 0, 'b^T y is not negative')


def modular_rank(matrix_rows, prime):
    require(prime >= 2 and all(prime % p for p in range(2, isqrt(prime) + 1)),
            'Rank modulus is not prime')
    work = [[v % prime for v in row] for row in matrix_rows]
    rank = 0
    for col in range(len(work[0]) if work else 0):
        pivot = next((i for i in range(rank, len(work)) if work[i][col]), None)
        if pivot is None:
            continue
        work[rank], work[pivot] = work[pivot], work[rank]
        inverse = pow(work[rank][col], prime - 2, prime)
        work[rank] = [v * inverse % prime for v in work[rank]]
        for i in range(rank + 1, len(work)):
            if work[i][col]:
                multiple = work[i][col]
                work[i] = [(a - multiple * b) % prime for a, b in zip(work[i], work[rank])]
        rank += 1
        if rank == len(work):
            break
    return rank


def check_case(C, rectangles, ids, certificate):
    equations, rhs, inconsistent, cells = build_exact_equations(C, rectangles, ids)
    kind = certificate['type']
    if kind == 'unique_cycle':
        require(inconsistent, 'Claimed inconsistent unique-entry cycle not found')
    elif kind in ('farkas', 'propagated_farkas'):
        require(not inconsistent, 'Unexpected cycle status')
        if kind == 'propagated_farkas':
            add_propagations(equations, rhs, cells, certificate['propagations'])
        check_farkas(equations, rhs, len(cells), certificate)
    elif kind == 'submatrix_rank':
        row_mask, col_mask = certificate['rows'], certificate['cols']
        rows, cols = members(row_mask, len(C)), members(col_mask, len(C))
        rank = modular_rank([[C[a][b] for b in cols] for a in rows], certificate['prime'])
        active = sum(bool(rectangles[j][0] & row_mask) and bool(rectangles[j][1] & col_mask)
                     for j in ids)
        require(rank == certificate['rank'] and rank > active, 'Rank obstruction failed')
    else:
        raise ValueError('Unknown rejection certificate: ' + kind)
    return kind
