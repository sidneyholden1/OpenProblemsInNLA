#!/usr/bin/env python3
"""Independent finite checks of the exact proof infrastructure (standard library)."""
from pathlib import Path
from itertools import combinations, product
from fractions import Fraction
import json
import random
import subprocess
import tempfile
from exact_core import *

ROOT = Path(__file__).resolve().parents[1]


def exact_rank(rows):
    work = [[Fraction(v) for v in row] for row in rows]
    rank = 0
    for j in range(len(work[0])):
        pivot = next((i for i in range(rank, len(work)) if work[i][j]), None)
        if pivot is None:
            continue
        work[rank], work[pivot] = work[pivot], work[rank]
        scale = work[rank][j]
        work[rank] = [v / scale for v in work[rank]]
        for i in range(rank + 1, len(work)):
            scale = work[i][j]
            work[i] = [v - scale * w for v, w in zip(work[i], work[rank])]
        rank += 1
        if rank == len(work):
            break
    return rank


def independent_rectangles():
    # Enumerate all 65,536 row families, rather than closing column sets.
    neighbors = [sum(1 << b for b in range(16) if (a & b).bit_count() != 1)
                 for a in range(16)]
    found = set()
    for rows in range(1, 1 << 16):
        cols = (1 << 16) - 1
        for a in members(rows, 16):
            cols &= neighbors[a]
        if cols:
            closure = sum(1 << a for a in range(16) if neighbors[a] & cols == cols)
            if closure == rows:
                found.add((rows, cols))
    require(sorted(found) == maximal_rectangles(4), 'Independent rectangle enumeration failed')
    print('PASS: independent enumeration of every nonempty row family gives the same 130 maximal rectangles.')


def n5_witness():
    record = json.loads((ROOT / 'data' / 'n5_relaxation_witness.json').read_text())
    ids = record['ids']
    rectangles = maximal_rectangles(5)
    require(len(ids) == len(set(ids)) == 31 and len(rectangles) == 2081, 'Bad five-bit witness size')
    C = matrix(5)
    for a in range(32):
        for b in range(32):
            if C[a][b]:
                require(any((rectangles[j][0] >> a) & 1 and (rectangles[j][1] >> b) & 1
                            for j in ids), 'Five-bit entry is uncovered')
    minima, counts = {}, {}
    for k in range(1, 5):
        values = []
        for free in combinations(range(5), k):
            fixed = [j for j in range(5) if j not in free]
            for state in product([(0, 0), (0, 1), (1, 0)], repeat=5 - k):
                rows = sum(1 << a for a in range(32)
                           if all(((a >> j) & 1) == u for j, (u, v) in zip(fixed, state)))
                cols = sum(1 << b for b in range(32)
                           if all(((b >> j) & 1) == v for j, (u, v) in zip(fixed, state)))
                active = sum(bool(rectangles[j][0] & rows) and bool(rectangles[j][1] & cols)
                             for j in ids)
                require(active >= 2 ** k, 'Five-bit face constraint failed')
                values.append(active)
        counts[k], minima[str(k)] = len(values), min(values)
    require(minima == record['face_active_minima'], 'Five-bit face minima mismatch')
    _, _, inconsistent, _ = build_exact_equations(C, rectangles, ids)
    require(inconsistent, 'Five-bit example should fail the unique-entry cycle test')
    print('PASS: 31 rectangles cover C_5 and meet all proper coordinate-face counts.', counts, minima)
    print('PASS: the same five-bit pattern has an exact cycle contradiction; it is NOT an NMF.')


def mutation_tests():
    cases = json.loads((ROOT / 'data' / 'cases15.json').read_text())['representatives']
    certificates = json.loads((ROOT / 'data' / 'certificates.json').read_text())
    certificate = next(c for c in certificates if c['type'] == 'farkas')
    corrupted = dict(certificate)
    corrupted['b_dot_y'] = 0
    try:
        check_case(matrix(4), maximal_rectangles(4), cases[certificate['i']], corrupted)
    except ValueError:
        pass
    else:
        raise ValueError('Corrupted Farkas constant accepted')
    corrupted = dict(certificate)
    corrupted['y'] = []
    try:
        check_case(matrix(4), maximal_rectangles(4), cases[certificate['i']], corrupted)
    except ValueError:
        pass
    else:
        raise ValueError('Empty false Farkas certificate accepted')
    print('PASS: certificate mutation tests reject corrupted evidence.')


def tiny_search_tests():
    rng = random.Random(20260912)
    with tempfile.TemporaryDirectory(prefix='nr03_selftest_') as directory:
        work = Path(directory)
        executable = work / 'cover'
        subprocess.run(['g++', '-std=c++17', '-O2', str(ROOT / 'code' / 'cover_enumerate.cpp'),
                        '-o', str(executable)], check=True)
        for trial in range(240):
            nv, ne, nf = rng.randint(1, 8), rng.randint(1, 8), rng.randint(0, 3)
            budget = rng.randrange(nv + 1)
            coverage = [[rng.randrange(2) for _ in range(nv)] for _ in range(ne)]
            faces = [[rng.randint(0, 3)] + [rng.randrange(2) for _ in range(nv)] for _ in range(nf)]
            # Unit-entry duals are always valid and exercise the exact dual check.
            duals = [[1] + [int(e == j) for e in range(ne)] for j in range(ne)]
            lines = [f'{nv} {ne} {nf} {ne}'] + [' '.join(map(str, r)) for r in coverage + faces + duals]
            model, output = work / 'model.txt', work / 'basis.txt'
            model.write_text('\n'.join(lines) + '\n')
            subprocess.run([str(executable), str(model), str(budget), str(output)],
                           check=True, stdout=subprocess.DEVNULL)
            basis = [set(map(int, line.split())) for line in output.read_text().splitlines()]

            def feasible(selected):
                return (len(selected) <= budget
                        and all(any(row[j] for j in selected) for row in coverage)
                        and all(sum(row[1 + j] for j in selected) >= row[0] for row in faces))

            require(all(feasible(leaf) for leaf in basis), 'Unsound tiny search leaf')
            for bits in range(1 << nv):
                selected = set(members(bits, nv))
                if feasible(selected):
                    require(any(leaf <= selected for leaf in basis), 'Incomplete tiny search basis')
    print('PASS: 240 deterministic small multicover models match exhaustive subset checks.')


if __name__ == '__main__':
    independent_rectangles()
    require(exact_rank(matrix(2)) == 4 and exact_rank(matrix(4)) == 11, 'Ordinary rank test failed')
    print('PASS: ordinary ranks are 4 for C_2 and 11 for C_4, by rational elimination.')
    n5_witness()
    mutation_tests()
    tiny_search_tests()
    print('ALL SELF-TESTS PASSED.')
