// Exhaustive integer-only binary multicover enumeration for the NR-03 proof.
// A returned leaf is a sufficient cover. Every feasible set of size <= budget
// contains at least one returned leaf. Search stops below sufficient leaves.
// No time limit, numerical optimizer, floating-point bound, or random choice.
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

struct Bits {
    std::uint64_t x[3] = {0, 0, 0};
    void set(int i) { x[i / 64] |= 1ULL << (i % 64); }
    void reset(int i) { x[i / 64] &= ~(1ULL << (i % 64)); }
    bool has(int i) const { return (x[i / 64] >> (i % 64)) & 1; }
    int count() const {
        return __builtin_popcountll(x[0]) + __builtin_popcountll(x[1])
             + __builtin_popcountll(x[2]);
    }
    bool empty() const { return !(x[0] | x[1] | x[2]); }
};
Bits operator&(Bits a, Bits b) { for (int i=0;i<3;++i) a.x[i]&=b.x[i]; return a; }
Bits operator|(Bits a, Bits b) { for (int i=0;i<3;++i) a.x[i]|=b.x[i]; return a; }
Bits operator-(Bits a, Bits b) { for (int i=0;i<3;++i) a.x[i]&=~b.x[i]; return a; }
bool operator==(Bits a, Bits b) {
    for (int i=0;i<3;++i) if (a.x[i]!=b.x[i]) return false;
    return true;
}
std::vector<int> indices(Bits bits) {
    std::vector<int> out;
    for (int j=0;j<3;++j) {
        auto word=bits.x[j];
        while (word) {
            int i=__builtin_ctzll(word);
            out.push_back(64*j+i);
            word&=word-1;
        }
    }
    return out;
}
struct Dual { std::int64_t denominator; std::vector<Bits> bit_planes; };
int nv, ne, nf, nd;
std::vector<Bits> covers, eligible, faces;
std::vector<Dual> duals;
std::vector<int> selected;
std::ofstream sink;
std::uint64_t nodes=0, dual_cuts=0, packing_cuts=0, face_cuts=0, zero_cuts=0, leaves=0;

std::int64_t weight(const Dual& dual, Bits uncovered) {
    std::int64_t sum=0;
    for (std::size_t k=0;k<dual.bit_planes.size();++k)
        sum+=std::int64_t((uncovered&dual.bit_planes[k]).count()) << k;
    return sum;
}

void search(int budget, Bits available, Bits uncovered, std::vector<int> need) {
    ++nodes;
    // Rank constraints. If every remaining slot must hit a face, exclude all
    // candidates missing it. Repeat because this can tighten other faces.
    bool changed=true;
    while (changed) {
        changed=false;
        for (int f=0;f<nf;++f) if (need[f]>0) {
            if (need[f]>budget) { ++face_cuts; return; }
            Bits options=available&faces[f];
            if (options.count()<need[f]) { ++face_cuts; return; }
            if (need[f]==budget && !(available==options)) {
                available=options; changed=true;
            }
        }
    }
    bool sufficient=uncovered.empty();
    if (sufficient) for (int value:need) if (value>0) sufficient=false;
    if (sufficient) {
        ++leaves;
        for (int j:selected) sink << j << ' ';
        sink << '\n';
        if (!sink) throw std::runtime_error("Cannot write cover basis");
        return;
    }
    if (budget==0) { ++zero_cuts; return; }
    // Each supplied dual was checked exactly at input. One chosen rectangle
    // covers uncovered-entry weight at most denominator, even after overlap.
    for (const auto& dual:duals)
        if (weight(dual,uncovered)>dual.denominator*budget) { ++dual_cuts; return; }

    int best=-1, minimum=100000;
    Bits options;
    std::vector<std::pair<int,Bits>> pending;
    for (int e:indices(uncovered)) {
        Bits candidates=available&eligible[e];
        int count=candidates.count();
        if (!count) { ++zero_cuts; return; }
        if (count<minimum) { minimum=count; best=e; options=candidates; }
        pending.push_back({count,candidates});
    }
    // If all entries are covered, an unmet face still requires a choice.
    if (best<0) for (int f=0;f<nf;++f) if (need[f]>0) {
        Bits candidates=available&faces[f];
        if (candidates.count()<minimum) {
            minimum=candidates.count(); best=ne+f; options=candidates;
        }
    }
    if (best<0) throw std::runtime_error("Missing branch constraint");
    // Pairwise disjoint candidate sets require distinct future rectangles.
    if (minimum>1) {
        std::sort(pending.begin(),pending.end(),
                  [](const auto& a,const auto& b){return a.first<b.first;});
        Bits used; int packed=0;
        for (const auto& item:pending) if ((used&item.second).empty()) {
            if (++packed>budget) { ++packing_cuts; return; }
            used=used|item.second;
        }
    }
    // Ordering changes speed only. Branches are partitioned by the first
    // selected candidate of the chosen uncovered-entry/unmet-face constraint.
    std::vector<std::pair<int,int>> ordered;
    for (int j:indices(options)) {
        int score=(covers[j]&uncovered).count()*10;
        for (int f=0;f<nf;++f) if (need[f]>0 && faces[f].has(j)) ++score;
        ordered.push_back({-score,j});
    }
    std::sort(ordered.begin(),ordered.end());
    for (auto item:ordered) {
        int j=item.second;
        available.reset(j); // also excludes earlier branch choices below
        auto next_need=need;
        for (int f=0;f<nf;++f) if (faces[f].has(j)) --next_need[f];
        selected.push_back(j);
        search(budget-1,available,uncovered-covers[j],next_need);
        selected.pop_back();
    }
}

int main(int argc,char** argv) {
    try {
        if (argc!=4) throw std::runtime_error("usage: cover_enumerate MODEL BUDGET OUTPUT");
        std::ifstream input(argv[1]);
        if (!input) throw std::runtime_error("Cannot open model");
        auto read=[&input](){int v; if (!(input>>v)) throw std::runtime_error("Truncated model"); return v;};
        auto bit=[&read](){int v=read(); if (v!=0 && v!=1) throw std::runtime_error("Nonbinary incidence"); return v;};
        int budget=std::stoi(argv[2]);
        nv=read(); ne=read(); nf=read(); nd=read();
        if (nv<1 || nv>192 || ne<1 || ne>192 || nf<0 || nd<0 || budget<0 || budget>192)
            throw std::runtime_error("Model dimension out of range");
        covers.resize(nv); eligible.resize(ne); faces.resize(nf);
        for (int e=0;e<ne;++e) for (int j=0;j<nv;++j) if (bit()) {
            covers[j].set(e); eligible[e].set(j);
        }
        std::vector<int> need(nf);
        for (int f=0;f<nf;++f) {
            need[f]=read();
            if (need[f]<0 || need[f]>192) throw std::runtime_error("Bad face demand");
            for (int j=0;j<nv;++j) if (bit()) faces[f].set(j);
        }
        for (int d=0;d<nd;++d) {
            int denominator=read(), maximum=0;
            if (denominator<=0 || denominator>1000000) throw std::runtime_error("Bad dual denominator");
            std::vector<int> weights(ne);
            for (int e=0;e<ne;++e) {
                weights[e]=read();
                if (weights[e]<0 || weights[e]>1000000) throw std::runtime_error("Bad dual weight");
                maximum=std::max(maximum,weights[e]);
            }
            for (int j=0;j<nv;++j) {
                std::int64_t sum=0;
                for (int e=0;e<ne;++e) if (covers[j].has(e)) sum+=weights[e];
                if (sum>denominator) throw std::runtime_error("Invalid exact dual");
            }
            Dual dual; dual.denominator=denominator;
            int levels=0; while ((1LL<<levels)<=maximum) ++levels;
            dual.bit_planes.resize(levels);
            for (int e=0;e<ne;++e) for (int k=0;k<levels;++k)
                if ((weights[e]>>k)&1) dual.bit_planes[k].set(e);
            duals.push_back(dual);
        }
        std::string extra;
        if (input>>extra) throw std::runtime_error("Trailing model data");
        sink.open(argv[3]);
        if (!sink) throw std::runtime_error("Cannot open output file");
        Bits available,uncovered;
        for (int j=0;j<nv;++j) available.set(j);
        for (int e=0;e<ne;++e) uncovered.set(e);
        search(budget,available,uncovered,need);
        sink.close();
        if (!sink) throw std::runtime_error("Cannot close output file");
        std::cout << "ENUMERATION_COMPLETE leaves=" << leaves << " nodes=" << nodes
                  << " dualcuts=" << dual_cuts << " packcuts=" << packing_cuts
                  << " facecuts=" << face_cuts << " zerocuts=" << zero_cuts << '\n';
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "VERIFICATION_ERROR: " << e.what() << '\n';
        return 2;
    }
}
