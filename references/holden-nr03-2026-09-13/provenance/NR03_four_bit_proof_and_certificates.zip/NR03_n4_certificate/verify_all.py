#!/usr/bin/env python3
"""Reproduce the complete exact C_4 proof, including exhaustive cover search.

Requirements: Python >=3.10, g++ or clang++ with C++17. No Python packages.
Usage: python3 verify_all.py [--compiler g++] [--work-dir PATH]
"""
import argparse
from collections import Counter
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
from exact_core import (require, matrix, verify_model, symmetry_group,
                        read_cover_basis, classify_multisets, check_case)


def verify(work, compiler):
    started = time.monotonic()
    data = ROOT / 'data'
    rectangles, coverage, faces = verify_model(data / 'model_faces.txt', True)
    verify_model(data / 'model_support.txt', False)
    print('PASS: exact matrix, 130 maximal rectangles, 148 positive entries, 49 rank-four faces.', flush=True)
    print('PASS: every supplied pruning dual satisfies all rectangle inequalities exactly.', flush=True)
    executable = work / 'cover_enumerate'
    subprocess.run([compiler, '-std=c++17', '-O2', '-Wall', '-Wextra', '-pedantic',
                    str(ROOT / 'code' / 'cover_enumerate.cpp'), '-o', str(executable)], check=True)
    runs = [ ('support', 12, 0), ('support', 13, 3), ('faces', 13, 0),
             ('faces', 14, 21), ('support', 14, 341), ('faces', 15, 13709) ]
    bases = {}
    for kind, budget, expected_count in runs:
        output = work / f'{kind}{budget}_candidates.txt'
        completed = subprocess.run([str(executable), str(data / f'model_{kind}.txt'),
                                    str(budget), str(output)], text=True,
                                   capture_output=True, check=True)
        require(completed.stdout.startswith('ENUMERATION_COMPLETE '), 'Search did not finish')
        basis = read_cover_basis(output, budget, coverage, faces if kind == 'faces' else [])
        require(len(basis) == expected_count, 'Unexpected cover-basis count')
        saved = data / output.name
        if saved.exists():
            saved_basis = [tuple(map(int, line.split())) for line in saved.read_text().splitlines()]
            require(sorted(map(sorted, basis)) == sorted(map(sorted, saved_basis)),
                    'Recomputed cover basis differs from supplied record')
        bases[kind, budget] = basis
        print(f'{kind:7s} budget={budget}: {completed.stdout.strip()}', flush=True)
    group = symmetry_group(rectangles)
    count, representatives = classify_multisets(bases['faces', 15], bases['support', 14], faces, group)
    expected = json.loads((data / 'cases15.json').read_text())
    require(count == expected['candidate_count'] == 16309, 'Candidate multiset mismatch')
    require(group == expected['group'], 'Symmetry action mismatch')
    require(representatives == [tuple(ids) for ids in expected['representatives']],
            'Symmetry representatives do not match recomputation')
    require(len(representatives) == 521, 'Wrong number of cases')
    print('PASS: every possible fifteen-term factorization is covered by 16,309 multisets / 521 symmetry cases.', flush=True)
    certificates = json.loads((data / 'certificates.json').read_text())
    require(len(certificates) == len(representatives), 'Missing or extra rejection certificate')
    kinds = Counter()
    C = matrix(4)
    for i, (ids, certificate) in enumerate(zip(representatives, certificates)):
        require(certificate['i'] == i, 'Certificate index mismatch')
        require(len(ids) == 15, 'Expected fifteen-atom multiset')
        kinds[check_case(C, rectangles, ids, certificate)] += 1
    require(kinds == Counter({'unique_cycle': 106, 'farkas': 413,
                              'submatrix_rank': 1, 'propagated_farkas': 1}),
            'Unexpected certificate type counts')
    print('PASS: all exact rejection certificates:', dict(sorted(kinds.items())), flush=True)
    require(all(v >= 0 for row in C for v in row), 'Nonnegative upper-bound factorization failed')
    print('PASS: C_4 = I_16 C_4 supplies the matching sixteen-term upper bound.', flush=True)
    print('RESULT: rank_+(C_4) = 16. No factorization with fifteen or fewer terms exists.', flush=True)
    print('SCOPE: this proves the four-bit case, not the conjecture for every n >= 5.', flush=True)
    print(f'Elapsed verification time on this run: {time.monotonic() - started:.3f} seconds.', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default=os.environ.get('CXX', 'g++'))
    parser.add_argument('--work-dir', type=Path)
    args = parser.parse_args()
    require(sys.version_info >= (3, 10), 'Python >=3.10 is required')
    if args.work_dir:
        args.work_dir.mkdir(parents=True, exist_ok=True)
        verify(args.work_dir.resolve(), args.compiler)
    else:
        with tempfile.TemporaryDirectory(prefix='nr03_exact_') as directory:
            verify(Path(directory), args.compiler)


if __name__ == '__main__':
    main()
