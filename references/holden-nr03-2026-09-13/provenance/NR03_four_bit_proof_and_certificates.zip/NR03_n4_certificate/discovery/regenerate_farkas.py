#!/usr/bin/env python3
"""Optionally rediscover the integer Farkas vectors using SciPy/HiGHS.

Not needed by verify_all.py. Supply a NEW output filename explicitly; this
script does not alter the shipped certificates unless you pass that path.
The solver may return different valid vectors on different versions/platforms.
All discovered vectors must pass the exact checker before they are written.
"""
import argparse
from fractions import Fraction
from math import gcd, lcm
from pathlib import Path
import json
import sys
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'code'))
from exact_core import (matrix, maximal_rectangles, build_exact_equations,
                        add_propagations, check_case, require)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    C, rectangles = matrix(4), maximal_rectangles(4)
    representatives = json.loads((ROOT / 'data' / 'cases15.json').read_text())['representatives']
    original = json.loads((ROOT / 'data' / 'certificates.json').read_text())
    result = []
    for i, ids in enumerate(representatives):
        old = original[i]
        if old['type'] in ('unique_cycle', 'submatrix_rank'):
            check_case(C, rectangles, ids, old)
            result.append(old)
            continue
        equations, rhs, bad, cells = build_exact_equations(C, rectangles, ids)
        require(not bad, 'Unexpected cycle')
        if old['type'] == 'propagated_farkas':
            add_propagations(equations, rhs, cells, old['propagations'])
        rr, cc, vv = [], [], []
        for row, equation in enumerate(equations):
            for column, value in equation.items():
                rr.append(row); cc.append(column); vv.append(value)
        A = csr_matrix((np.asarray(vv, dtype=float), (rr, cc)),
                       shape=(len(equations), len(cells)))
        b = np.asarray(rhs, dtype=float)
        solution = linprog(b, A_ub=-A.T, b_ub=np.zeros(len(cells)),
                           bounds=(-1, 1), method='highs')
        require(solution.success and solution.fun < 0, f'No negative separator for case {i}')
        fractions = [Fraction(float(v)).limit_denominator(1_000_000) for v in solution.x]
        denominator = lcm(*(v.denominator for v in fractions))
        y = [int(v * denominator) for v in fractions]
        divisor = gcd(*y)
        require(divisor > 0, 'Zero separator')
        y = [v // divisor for v in y]
        certificate = {'i': i, 'type': old['type'],
                       'variables': len(cells), 'equations': len(equations),
                       'y': [[j, v] for j, v in enumerate(y) if v],
                       'b_dot_y': sum(v * w for v, w in zip(rhs, y))}
        if old['type'] == 'propagated_farkas':
            certificate['propagations'] = old['propagations']
        check_case(C, rectangles, ids, certificate)
        result.append(certificate)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, separators=(',', ':')))
    print(f'Wrote {len(result)} exactly checked certificates to {args.output}')


if __name__ == '__main__':
    main()
