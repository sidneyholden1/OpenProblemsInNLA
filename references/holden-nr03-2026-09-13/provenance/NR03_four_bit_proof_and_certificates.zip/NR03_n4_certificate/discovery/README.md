# Optional discovery, not a verification dependency

`regenerate_farkas.py` uses NumPy and SciPy's HiGHS linear-programming interface
to rediscover the 413 initial and one propagated separating vectors. It keeps
the cycle/rank certificates and the four explicit propagation derivations.

```sh
python3 discovery/regenerate_farkas.py /tmp/nr03_rediscovered.json
```

The output vectors may differ from the delivered ones. Each is converted to
integers and must pass the exact standard-library checker before output.
A floating-point optimizer status is never substituted for an exact proof.

The main verifier needs none of these numerical packages. See
`logs/environment.txt` for versions actually used in the recorded run.
