# Sources and scope

Sources were read through their public websites or raw website text. Access
check: September 12, 2026. No GitHub connector/plugin was used.

## The exact task

OpenProblemsInNLA, **NR-03 — Full nonnegative rank of the quadratic correlation
matrix**. Defines the prescribed matrix and records the existing three-bit
result and remaining scope. This was the controlling problem statement.

https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/nonnegative-and-positive-factorizations/NR-03

Raw statement:
https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/nonnegative-and-positive-factorizations/NR-03/README.md

Repository contribution guidance:
https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/CONTRIBUTING.md

## Original conjecture

Arnaud Vandaele, Nicolas Gillis, François Glineur, and Daniel Tuyttens,
**Heuristics for Exact Nonnegative Matrix Factorization**, arXiv:1411.7245,
Section 6.4, Conjecture 4.

https://arxiv.org/html/1411.7245

## Benchmark bounds used for comparison

Timothy Baeckelant, Arnaud Vandaele, and Nicolas Gillis,
**Computing Lower Bounds on the Nonnegative Rank via Non-Convex Optimization
Solvers**, arXiv:2605.14058v2, July 6, 2026, Section 6.7 and Appendix A.4,
Table 9. Reports the four-bit nonnegative-rank interval 13–16.

https://arxiv.org/html/2605.14058v2

## Important distinction: a different completion problem

I. S. Sergeev, **Upper bounds for the monotone rank of the unique disjointness
matrix**, arXiv:2607.27014v1, July 29, 2026. The entries for intersection size
larger than one are not prescribed as in NR-03. This result is not used to
infer a rank bound for the fixed matrix in the theorem.

https://arxiv.org/html/2607.27014v1

## Existing three-bit proof consulted

Matthew J. Colbrook, authored three-bit theorem linked from the repository:

https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/references/colbrook-factorization-2026-09-11/manuscripts/NR-03_n3_exact_rank.tex

That proof's parity condition is not extended to arbitrary wider factors in
this work. The four-bit proof in this package is self-contained and uses only
ordinary rank four of two-bit faces for its cover constraints.

## Provenance of the new computation

The four-bit enumeration, exact certificates, exceptional-case hand proofs,
standalone verification routines, and five-bit relaxation-only example were
generated and checked in this session. No claim of external human review or
proof-assistant formalization is made.
