# Exact status of this work

## Proved in this package

For the prescribed sixteen-by-sixteen real nonnegative matrix
`C_4(a,b) = (1 - popcount(a & b))^2`, the nonnegative rank is exactly sixteen.
The lower bound is an exhaustive, reproducible, integer/rational
computer-assisted proof. The upper bound is `C_4 = I_16 C_4`.

The ordinary rank is eleven. The support covering number is thirteen; the
latter reproduces an existing bound rather than being claimed as a new one.
The numerical entries, not only the zero pattern, are used to rule out every
factorization of width fifteen.

## Not proved here

The quantified assertion `rank_+(C_n) = 2^n` for every `n >= 5`.
No induction establishing that assertion and no counterexample factorization
are supplied. A five-bit support-relaxation witness is included solely to
identify a failed induction shortcut; it is not a factorization.

## Relationship to NR-03

The problem page checked in this session already records the `n=3` theorem.
This package supplies a four-bit theorem. The full NR-03 problem therefore
should not be described as solved on the strength of this package.

Suggested scope language for a future reviewed submission:

> An exact computer-assisted proof establishes the fixed four-bit case
> `rank_+(C_4)=16`. All maximal-support cases for a hypothetical fifteen-term
> factorization are exhausted and rejected by exact certificates. The
> prescribed-completion conjecture for every `n >= 5` is not resolved by this
> result.

No GitHub plugin was used, no repository change was made, no external reviewer
was consulted, and no formal proof-assistant certificate is claimed.
