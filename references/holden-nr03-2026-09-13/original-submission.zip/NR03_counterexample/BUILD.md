# Reproducing the files and checks

## Verify the counterexample

From this directory, with Python 3.10 or newer:

```bash
python3 verify_all.py
```

No dependencies outside the Python standard library are needed. The certificate
verifiers do not write to the data files. Python may create `__pycache__` folders;
set `PYTHONDONTWRITEBYTECODE=1` to suppress these.

## Regenerate all n=7 factor files

```bash
python3 code/factorization.py --n 7 --out regenerated
```

The files in `regenerated/` should be byte-for-byte identical to their namesakes
in `data/`. The test suite also checks the construction against the JSON data.

## Optional C++ verification

```bash
g++ -std=c++17 -O2 code/verify_csv.cpp -o verify_csv
./verify_csv data
```

Replace `g++` by `clang++` to use Clang. The shipped logs record successful runs
with both compilers. No executable files are included.

## Rebuild the mathematical paper

With a LaTeX distribution providing the packages named in the source:

```bash
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build NR03_counterexample.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build NR03_counterexample.tex
```

This produces `build/NR03_counterexample.pdf`. The delivered PDF has six pages;
all six rendered pages were inspected. The final compiler run reported no
undefined references, overfull boxes, underfull boxes, or warnings. Exact PDF
bytes can vary across TeX distributions and build timestamps; the factors and
integer proof checks do not depend on TeX.

## Integrity

`SHA256SUMS.txt` records every package file other than the manifest itself.
On systems providing `sha256sum`, verify the package with:

```bash
sha256sum -c SHA256SUMS.txt
```

The earlier four-bit ZIP under `provenance/` is unchanged from the previous
conversation output. Its historical scope statement is not the current status
of the universal question; consult the new `STATUS.md`.
