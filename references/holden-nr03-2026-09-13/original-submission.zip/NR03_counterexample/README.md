# NR-03: a counterexample and a general nonnegative factorization

## Answer to the stated question: no

For the **fully prescribed** matrix

\[
C_n(a,b)=(1-|a\cap b|)^2,\qquad a,b\subseteq[n],
\]
this package proves

\[
\operatorname{rank}_+(C_n)
\le 2^{n-1}+n+\binom n2+\binom n4.
\]
In particular,

\[
\boxed{\operatorname{rank}_+(C_7)\le64+7+21+35=127<128.}
\]
The same bound is strictly below \(2^n\) for **every \(n\ge7\)**. Thus the universal equality in NR-03 is false. This is a complete negative answer to the question, not merely a special-case lower bound. It does **not** assert that 127 is the exact nonnegative rank, or that 7 is the smallest counterexample dimension.

## Read the proof

- `NR03_counterexample.pdf`: self-contained mathematical paper, explicit factor formulas, and verification details.
- `NR03_counterexample.tex`: editable LaTeX source.
- `PROOF.md`: the mathematical argument in Markdown.
- `STATUS.md`: exact scope and review status.

The proof is analytic. The software is an additional reproducible check, not a required search or unproved numerical premise.

## Verify the actual counterexample

Python 3.10 or later; **no third-party packages, optimizer, network, or compiler required**:

```bash
python3 code/verify_certificate.py
```

This reads the supplied matrices without importing the construction and checks every one of the 16,384 entries using arbitrary-precision integers. The smaller independent checker is:

```bash
python3 code/verify_minimal.py
```

Run the full test suite:

```bash
python3 verify_all.py
```

The suite regenerates the certificate exactly; verifies complete matrices for n=1,...,9; checks the polynomial identity coefficient by coefficient; verifies the unscaled rational CSV factors; and rejects six intentionally damaged certificates. Successful logs are included in `logs/`.

## Use the factors

`data/W_n7.csv` has shape 128 x 127. `data/H_n7_rational.csv` has shape 127 x 128 and stores exact integers or fraction strings. **These two matrices multiply to C_7 itself.**

Alternatively, all entries in `data/factors_n7.json` are integers. Write `V = H_scaled` and `d = denominators`. Then

\[
WV=C_7\operatorname{diag}(d),\qquad
C_7=W\bigl(V\operatorname{diag}(d)^{-1}\bigr).
\]

The denominators are positive; their possible values are 1, 4, 9, 16, 25, 36. The left factor uses only 0, 1, 2, and the integer-scaled right factor has maximum entry 36.

Rows and columns are ordered by subset masks 0,...,127. Bit i denotes element i+1. Atom order and the relevant subset masks are recorded in `data/atom_index_n7.csv` and in the JSON.

Regenerate the files into a separate directory:

```bash
python3 code/factorization.py --n 7 --out regenerated
```

The general construction is implemented for every positive n, subject only to the exponential memory needed to materialize its factors. The command requires `--allow-large` above n=10 to prevent accidental excessive allocation.

## Optional second-language check

```bash
g++ -std=c++17 -O2 code/verify_csv.cpp -o verify_csv
./verify_csv data
```

This checker reads the integer CSV matrices directly. It was run successfully with both GCC and Clang. These are different implementations, **not a claim of an independent human or AI-agent review**.

## Relation to the previous four-bit result

The earlier exact proof that rank_+(C_4)=16 is preserved unchanged in `provenance/NR03_four_bit_proof_and_certificates.zip`. Its verifier was rerun successfully, and that log is included. The new counterexample is compatible with the four-bit theorem and does not depend on it. The earlier package's “remaining n>=5” statement is historical; the present package resolves the universal question negatively.

## Review status

The construction, algebra, explicit factors, and checks were developed and tested in this conversation. They have not been externally peer-reviewed or proof-assistant formalized. Under the repository's stated evidence rules, this is a **complete solution claim by counterexample**, ready for independent audit; no live repository files were changed. See `repo_submission.md` for a draft resolution note and `SOURCES.md` for primary references.
