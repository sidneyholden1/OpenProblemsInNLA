# Exact mathematical scope and review status

## Mathematical outcome

**The universally quantified equality in NR-03 is false.**

The package proves an explicit general upper bound

`rank_+(C_n) <= 2^(n-1) + n + binom(n,2) + binom(n,4)`

and supplies complete rational factors with inner dimension 127 for the prescribed 128 x 128 matrix C_7. The bound is strictly below 2^n for every n >= 7.

This is a complete negative resolution of the displayed yes/no question. It is not merely the prior four-bit partial theorem.

## Claims deliberately not made

- That rank_+(C_7) equals 127, rather than being at most 127.
- That n=7 is the smallest counterexample: the exact answers at n=5 and n=6 are not determined here.
- That the nonnegative rank of the full correlation-polytope slack matrix, or the polytope's extension complexity, has been determined.
- That tests at finitely many n prove the all-n upper bound: the analytic identity and counting argument prove it.
- That the work has external peer review, an independent reviewing agent, or proof-assistant certification.

## Repository evidence status

The repository distinguishes **SOLUTION CLAIMED** from **SOLVED**. Its rule admits counterexamples as complete resolutions, but requires publication or an independent audit for the latter label. The current work contains a full manuscript and exact reproducible certificates, but the checks were performed within this conversation. Therefore the defensible submission label at this point is **SOLUTION CLAIMED — complete negative resolution by counterexample**. After a genuinely independent successful audit, the same mathematical scope supports **SOLVED**.

No live repository changes were made. A draft submission note is provided in `repo_submission.md`.

## Prior work preserved

The previous archive `NR03_four_bit_proof_and_certificates.zip` is included unchanged under `provenance/`. Its complete four-bit verification was rerun successfully. That result remains valid and is not needed for the counterexample.
